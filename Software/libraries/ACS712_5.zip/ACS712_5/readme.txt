
REV V.0.1 || Date : 25-08-2023 || Time : 12:27AM
1. Changed the argument data type from char to byte because char ~ int8_t and byte ~ uint8_t

REV V.1.2 || Date : 13-09-2023 || Time : 03:10PM
1. Changing Complete library as it is showing a saturated value at 1.80 Amp.