/*
@Author : BHAVAY SEN
DATE : 13-09-2023
REV : V.1.0
*/

#ifndef ACS712_5
#define ACS712_5
/*
Arguments : 
Vref : Refernce Voltage
Samples : No. of samples
adcPin : A0 - A7
*/
float currentSense(float Vref, byte samples, byte adcPin);

#endif
