#include <Arduino.h>
#include "USP10976.h"

float temperatureSense(float Vref, char Samples, char adcPin, float R2){ 

  float V_R2 = ((analogRead(adcPin))*Vref)/1024.0; // Voltage Drop across R2
  //Resistance Value of Thermistor
  float Rth = log(((Vref*R2*1000.0)/V_R2)-(R2*1000.0)); 
  //Calculating taapmaan through S-H Equation 
  float Temp_k = 1/(A+(B*Rth)+(C*Rth*Rth*Rth)); // in Kelvin
  //Calculating temperature to Degree C
  return Temp_k-273.15; // Converting K to C
}