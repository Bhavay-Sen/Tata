#ifndef USP10976
#define USP10976 

const float  A = 0.001128369370,
             B = 0.0002342933297,
             C = 0.00000008681204;

/*
Vref = Reference Voltage,
Samples = No. of Adc readings, 
Adc Pin, 
Value of R2 in Kohms
*/
float temperatureSense(float Vref, char Samples, char adcPin, float R2);

#endif