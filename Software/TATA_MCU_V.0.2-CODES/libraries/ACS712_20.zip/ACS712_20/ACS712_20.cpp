/*
@Author : BHAVAY SEN
DATE : 13-09-2023
REV : V.1.0
*/

#include <Arduino.h>
#include "ACS712_20.h"

float currentSense(float Vref, byte samples, byte adcPin){
  
unsigned int x=0;
float AcsValue=0.0,Samples=0.0,AvgAcs=0.0,AcsValueF=0.0;

  for (x = 0; x < samples; x++){ //Get 150 samples
  AcsValue = analogRead(adcPin);     //Read current sensor values   
  Samples = Samples + AcsValue;  //Add samples together
  delay (1); // let ADC settle before next sample 3ms
}
AvgAcs=Samples/samples;//Taking Average of Samples
AcsValueF = (2.5 - (AvgAcs * (Vref / 1024.0)) )/0.100;

return AcsValueF;
}
