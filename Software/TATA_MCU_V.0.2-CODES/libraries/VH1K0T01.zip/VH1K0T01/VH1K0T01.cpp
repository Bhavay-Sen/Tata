/*
@Author : BHAVAY SEN
DATE : 22-08-2023
REV : ORIGINAL
*/

#include "VH1K0T01.h"
#include <Arduino.h>

//Function Body
  float terminalVoltage(float Vref, char samples, int adcPin, float Rin, float Rb){
    float meanData = 0.0, adcRead = 0.0; 
    for(int i = 0; i < samples ; i++){
      adcRead = (analogRead(adcPin) * Vref) / 1024.0;
      meanData += adcRead;
    }
    meanData /= samples;
    //Formula derived from VH1K0T01
    return (meanData * Rin * 1000) / (2.5 * Rb);
  }