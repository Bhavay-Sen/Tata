/*
@Author : BHAVAY SEN
DATE : 22-08-2023
REV : ORIGINAL
*/

#ifndef VH1K0T01
#define VH1K0T01
/* 
  Parameters :
  Vref : Voltage reference value
  Samples : no. of samples 
  adc pin : A0-A7
  Rin : load Resistance in Kohms
  Rb : Burden Resistance in ohms
*/

//ADC read check
  float terminalVoltage(float Vref, char samples, int adcPin, float Rin, float Rb);

#endif